import React from "react";
import "../styles.css";

const Header = () => {
  return (
    <div className="header-container">
      <h1>Dashboard de Obras en Medellín</h1>
    </div>
  );
};

export default Header;
